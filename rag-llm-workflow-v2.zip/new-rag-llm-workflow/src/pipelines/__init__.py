# Pipeline implementations
